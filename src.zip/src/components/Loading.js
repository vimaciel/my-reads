import React, { Component } from "react";
import '../styles/Loading.css';

class Loading extends Component {
    render() {
        return (
            <div className="loading" style={{ display: this.props.show ? 'block' : 'none' }}>
                <div className="cssload-cube cssload-c1"></div>
                <div className="cssload-cube cssload-c2"></div>
                <div className="cssload-cube cssload-c4"></div>
                <div className="cssload-cube cssload-c3"></div>
            </div>
        )
    }
}

export default Loading;