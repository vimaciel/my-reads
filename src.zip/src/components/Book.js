import React, { Component } from "react";
import BookShelfChanger from './BookShelfChanger';

class Book extends Component {
    state = {
        movingBook: false
    }

    createBookTitle = () => {
        const year = this.props.book.publishedDate.split('-')[0];
        return `${this.props.book.title} (${year})`;
    }

    moveBook = (shelf) => {
        this.setState({ movingBook: !this.state.movingBook });
        this.props.moveBook(this.props.book, shelf);
    }

    render() {
        return (
            <div className="book">
                <div className="book-top">
                    <div className="book-cover" style={{ width: 128, height: 193, backgroundImage: `url(${this.props.book.imageLinks.thumbnail})` }}></div>
                    <BookShelfChanger shelf={this.props.book.shelf} moveBook={this.moveBook} />
                </div >
                {this.state.movingBook ? (
                    <i className="moving-book"> moving the book...</i>
                ) : (
                        <div>
                            <div className="book-title">{this.createBookTitle()}</div>
                            <div className="book-authors">
                                <ol>
                                    {this.props.book.authors.map(author => (
                                        <li key={this.props.book.authors.indexOf(author)}>{author}</li>
                                    ))}
                                </ol>
                            </div>
                        </div>
                    )}
            </div>
        )
    }
}

export default Book;